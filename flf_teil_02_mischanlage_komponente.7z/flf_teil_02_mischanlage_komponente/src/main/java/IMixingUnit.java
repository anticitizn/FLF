import java.util.ArrayList;

public interface IMixingUnit<EquipmentType, WaterTank, FoamPowderTank> {

    void switchRatio(EquipmentType equipmentType);
    void setRatio(int ratio, EquipmentType equipmentType);
    void drain(int amount, EquipmentType equipmentType);
    void setData(WaterTank WaterTank, FoamPowderTank FoamPowderTank, EquipmentType equipmentTypeFrontLauncher, EquipmentType equipmentTypeRoofExtinguishingArm);
    ArrayList<Integer> getFluidUsed();
    void clearFluidUsed();
}
