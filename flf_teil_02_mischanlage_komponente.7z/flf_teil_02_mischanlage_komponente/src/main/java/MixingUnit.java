
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;

public class MixingUnit<EquipmentType, WaterTank, FoamPowderTank> {

    private static final MixingUnit instance = new MixingUnit();


    public Port port;
    private int ratioState;
    private HashMap<EquipmentType, Integer> ratios;
    private WaterTank waterTank;
    private FoamPowderTank foamPowderTank;
    ArrayList<Integer> fluidUsed;


    private MixingUnit() {
        port = new Port();
    }


    public static MixingUnit getInstance() {
        return instance;
    }


    public void InnerSwitchRatio(EquipmentType equipmentType) {
        switch (ratioState) {
            case 0 -> {
                InnerSetRatio(3, equipmentType);
                ratioState = 1;
            }
            case 1 -> {
                InnerSetRatio(5, equipmentType);
                ratioState = 2;
            }
            case 2 -> {
                InnerSetRatio(10, equipmentType);
                ratioState = 3;
            }
            case 3 -> {
                InnerSetRatio(0, equipmentType);
                ratioState = 0;
            }
        }
    }

    public void InnerSetRatio(int ratio, EquipmentType equipmentType) {
        ratios.put(equipmentType, ratio);
        System.out.println(ratios.get(equipmentType));
    }

    public void InnerDrain(int amount, EquipmentType equipmentType) {
        int ratio = ratios.get(equipmentType);
        int foamUsed = (int)(amount * (ratio / 100.0f));
        int waterUsed = amount - foamUsed;

        fluidUsed.add(foamUsed);
        fluidUsed.add(waterUsed);

    }

    public ArrayList<Integer> InnerGetFluidUsed() {
        return fluidUsed;
    }

    public void InnerClearFluidUsed(){
       fluidUsed.clear();
    }

    // inner class port
    public class Port implements IMixingUnit {
       public void switchRatio(Object equipmentType){InnerSwitchRatio((EquipmentType) equipmentType);}

        public void setRatio(int ratio, Object equipmentType){InnerSetRatio(ratio, (EquipmentType) equipmentType);}

        public void drain(int amount, Object equipmentType){InnerDrain(amount, (EquipmentType) equipmentType);}

        public void setData(Object WaterTank, Object FoamPowderTank, Object equipmentTypeFrontLauncher, Object equipmentTypeRoofExtinguishingArm){
            waterTank = (WaterTank) WaterTank;
            foamPowderTank = (FoamPowderTank) FoamPowderTank;
            ratios = new HashMap<>();
            ratios.put((EquipmentType) equipmentTypeFrontLauncher, 0);
            ratios.put((EquipmentType) equipmentTypeRoofExtinguishingArm, 0);
            ratioState = 0;
            fluidUsed = new ArrayList<>();
        }

        public ArrayList<Integer> getFluidUsed(){return InnerGetFluidUsed();}

        public void clearFluidUsed(){InnerGetFluidUsed();}

    }


}
